The code in this directory is copyright of Takeaki Uno <uno@nii.jp> and Keisuke Murakami <murakami@ise.aoyama.ac.jp>.
It is available in its most current form from the [Hypergraph Dualization Repository](//research.nii.ac.jp/~uno/dualization.html) and was written for their paper [_Efficient algorithms for dualizing large-scale hypergraphs_](//doi.org/10.1016/j.dam.2014.01.012).
