The C code in this directory was written by K. Elbassioni and distributed at the website of [Endre Boros](//rutcor.rutgers.edu/~boros/IDM/DualizationCode.html).
It is included here by permission of the author and is provided as-is and without warranty.
