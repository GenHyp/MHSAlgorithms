The C++ code in this directory was written by Céline Hébert and available from the MTMiner project [website](//forge.greyc.fr/projects/kdariane/wiki/Mtminer).
It is provide as-is and without warranty.

