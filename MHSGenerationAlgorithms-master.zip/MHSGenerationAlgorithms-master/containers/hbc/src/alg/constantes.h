#define ATT unsigned short int
#define OBJ unsigned int
#define MAX_TRANS 1000000
