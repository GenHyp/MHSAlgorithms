#ifndef __TIME_H_917d7248e9cacb20648c5598f629c81fa833a1e7__
#define __TIME_H_917d7248e9cacb20648c5598f629c81fa833a1e7__

typedef long double t_time_interval;

t_time_interval time_interval ();

#endif