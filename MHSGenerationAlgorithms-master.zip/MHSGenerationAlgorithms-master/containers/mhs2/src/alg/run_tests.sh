#!/bin/sh

BUILD_DIR="build"
TEST_DIR="tests"

cd $TEST_DIR
../$BUILD_DIR/test
