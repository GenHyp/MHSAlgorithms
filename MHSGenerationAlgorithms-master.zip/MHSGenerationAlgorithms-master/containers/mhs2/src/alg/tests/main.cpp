#define BOOST_TEST_MODULE libdiag
#include <boost/test/included/unit_test.hpp>