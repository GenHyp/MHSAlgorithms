The C++ code was written by [Takeaki Uno]<uno@nii.jp> and distributed at his [website](//research.nii.ac.jp/~uno/code/shd.html), where the latest version is always available.
It is redistributed here without modification under the terms of the notice at the top of that page:

> This program is available for only academic use, basically.
> Anyone can modify this program, but he/she has to write down the change of the modification on the top of the source code.
> Neither contact nor appointment to Takeaki Uno is needed.
> If one wants to re-distribute this code, do not forget to refer the newest code, and show the link to homepage of Takeaki Uno, to notify the news about SHD for the users.
> For the commercial use, please make a contact to Takeaki Uno.
